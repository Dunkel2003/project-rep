#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include "zeichenketten_functions.h"
#include "liste.h"