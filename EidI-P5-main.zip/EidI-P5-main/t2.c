#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include "zeichenketten_functions.h"
#include "zeichenketten_functions.c"

int main(void){
    getUserInputMainMenu();

    return 0;
}